package com.example.projecttwo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private List<InventoryItem> itemList;
    private OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(int itemId);
    }

    public InventoryAdapter(List<InventoryItem> itemList, OnDeleteClickListener deleteClickListener) {
        this.itemList = itemList;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_item, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.nameTextView.setText(item.getName());
        holder.quantityTextView.setText("Qty: " + item.getQuantity());
        holder.descriptionTextView.setText(item.getDescription());
        holder.deleteButton.setOnClickListener(v -> deleteClickListener.onDeleteClick(item.getId()));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public void setItems(List<InventoryItem> newItems) {
        itemList = newItems;
        notifyDataSetChanged();
    }

    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, quantityTextView, descriptionTextView;
        Button deleteButton;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.itemName);
            quantityTextView = itemView.findViewById(R.id.itemQuantity);
            descriptionTextView = itemView.findViewById(R.id.itemDescription);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}