package com.example.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements InventoryAdapter.OnDeleteClickListener {

    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private List<InventoryItem> inventoryList;
    private InventoryDatabaseHelper dbHelper;
    private Button addItemButton, goToSmsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.inventoryRecyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        goToSmsButton = findViewById(R.id.goToSmsButton);
        dbHelper = new InventoryDatabaseHelper(this);

        inventoryList = new ArrayList<>();
        adapter = new InventoryAdapter(inventoryList, this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        loadInventory();

        addItemButton.setOnClickListener(view -> showAddItemDialog());

        goToSmsButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }

    private void showAddItemDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        final android.view.View dialogView = inflater.inflate(R.layout.dialog_add_item, null);

        final EditText itemNameInput = dialogView.findViewById(R.id.itemNameInput);
        final EditText itemQuantityInput = dialogView.findViewById(R.id.itemQuantityInput);
        final EditText itemDescriptionInput = dialogView.findViewById(R.id.itemDescriptionInput);

        new AlertDialog.Builder(this)
                .setTitle("Add Inventory Item")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = itemNameInput.getText().toString();
                    String quantityStr = itemQuantityInput.getText().toString();
                    String description = itemDescriptionInput.getText().toString();

                    if (name.isEmpty() || quantityStr.isEmpty() || description.isEmpty()) {
                        Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int quantity = Integer.parseInt(quantityStr);
                    boolean success = dbHelper.addItem(name, quantity, description);

                    if (success) {
                        Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
                        loadInventory();
                    } else {
                        Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadInventory() {
        inventoryList.clear();
        Cursor cursor = dbHelper.getAllItems();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

                inventoryList.add(new InventoryItem(id, name, quantity, description));
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter.setItems(inventoryList);
    }

    @Override
    public void onDeleteClick(int itemId) {
        boolean deleted = dbHelper.deleteItem(itemId);
        if (deleted) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            loadInventory();
        } else {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }
}